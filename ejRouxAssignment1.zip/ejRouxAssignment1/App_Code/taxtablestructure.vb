﻿Public Structure TaxTableStructure
    Public AtLeast, ButLessThan, SingleTax, MarriedFilingJointlyTax, MarriedFilingSeparatelyTax, HeadOfHouseholdTax As Double
End Structure
