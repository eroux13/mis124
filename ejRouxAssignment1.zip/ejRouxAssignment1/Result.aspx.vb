﻿
Partial Class _Default
    Inherits Page
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Try
            Dim taxInformationResults As clsTaxReturn = Session("taxInformation")
            Me.txtSalaries.Text = FormatCurrency(taxInformationResults.Wages)
            Me.txtTaxableInterest.Text = FormatCurrency(taxInformationResults.TaxableInterest)
            Me.txtUnemployment.Text = FormatCurrency(taxInformationResults.UnemploymentCompensation)
            Me.txtFederalIncome.Text = FormatCurrency(taxInformationResults.IncomeTaxWithheld)
            Me.txtEIC.Text = FormatCurrency(taxInformationResults.EIC)
            Me.txtNonTaxable.Text = FormatCurrency(taxInformationResults.CompatPay)
            Me.lblNumberOfDependents.Text = Session("stringNumberOfDependents")

            ' Calculate Tax Return
            taxInformationResults.calculateTaxReturn()

            ' Calculated fields
            Me.lblAdjustedGrossIncome.Text = FormatCurrency(taxInformationResults.AdjustedGrossIncome)
            Me.txtSalaries.Text = FormatCurrency(taxInformationResults.Wages)
            Me.txtSalaries.Text = FormatCurrency(taxInformationResults.Wages)
            Me.txtSalaries.Text = FormatCurrency(taxInformationResults.Wages)
            Me.txtSalaries.Text = FormatCurrency(taxInformationResults.Wages)


        Catch ex As Exception

        End Try
    End Sub
    Protected Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnGoBack.Click
        Response.Redirect("Default.aspx")
    End Sub

End Class