﻿
Partial Class Contact
    Inherits Page

End Class