﻿
Partial Class _Default
    Inherits Page
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        ckbSpouse.Enabled = False
        ckbYou.Enabled = False
        Try
            If Not IsPostBack Then
                ' Get cookie
                Dim myCookie As HttpCookie = Request.Cookies("FullName")
                If myCookie IsNot Nothing Then
                    txtFullName.Text = myCookie.Value
                End If

                ' Get Session
                If (Session.Count > 0) Then
                    Dim savedTaxInformation As clsTaxReturn = Session("taxInformation")
                    Me.txtSalaries.Text = savedTaxInformation.Wages
                    Me.txtTaxableInterest.Text = savedTaxInformation.TaxableInterest
                    Me.txtUnemployment.Text = savedTaxInformation.UnemploymentCompensation
                    Me.txtFederalIncome.Text = savedTaxInformation.IncomeTaxWithheld
                    Me.txtEIC.Text = savedTaxInformation.EIC
                    Me.txtNonTaxable.Text = savedTaxInformation.CompatPay
                    Me.ddlTaxReturn.Items.FindByText(Session("stringNumberOfPeople")).Selected = True
                    Me.txtFullName.Text = Session("fullName")
                    Dim stringNumberOfDependents As String = Session("stringNumberOfDependents")
                    If (Me.ddlTaxReturn.Items.FindByText("Joint").Selected = True) Then
                        ckbSpouse.Enabled = True
                    End If
                    If (stringNumberOfDependents = "You Spouse") Then
                        ckbYou.Checked = True
                        ckbSpouse.Enabled = True
                        ckbSpouse.Checked = True
                    ElseIf (stringNumberOfDependents = "You") Then
                        ckbYou.Checked = True
                    ElseIf (stringNumberOfDependents = "Spouse") Then
                        ckbSpouse.Checked = True
                        ckbSpouse.Enabled = True
                    End If
                End If
            End If
        Catch ex As Exception
            lblMessage.Text = ex.Message
        End Try
    End Sub
    ' Disable Spouse checkbox when "Individual" is selected
    Protected Sub ddlTaxReturn_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ddlTaxReturn.SelectedIndexChanged
        If (ddlTaxReturn.SelectedValue = "Individual") Then
            ckbSpouse.Enabled = False
            ckbYou.Enabled = True
        Else
            ckbSpouse.Enabled = True
            ckbYou.Enabled = True
        End If

    End Sub
    Protected Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Try
            ' Cookie to store full name
            Dim myCookie As New HttpCookie("FullName", txtFullName.Text)
            myCookie.Expires = DateTime.MaxValue
            Response.Cookies.Add(myCookie)

            ' Get Individual or Joint Tax Return
            Dim numberOfPeople As Integer = 0
            Dim stringNumberOfPeople As String = ""
            If (ddlTaxReturn.SelectedValue = "1") Then
                numberOfPeople = 1
                stringNumberOfPeople = "Individual"
            ElseIf (ddlTaxReturn.SelectedValue = "2") Then
                numberOfPeople = 2
                stringNumberOfPeople = "Joint"
            End If

            ' Get You/Spouse from Checkboxes
            Dim numberOfDependents As Integer = 0
            Dim stringDependents As String = ""
            If (ckbSpouse.Checked = True And ckbYou.Checked = True) Then
                numberOfDependents = 2
                stringDependents = "You Spouse"
            ElseIf (ckbYou.Checked = True) Then
                numberOfDependents = 1
                stringDependents = "You"
            ElseIf (ckbSpouse.Checked = True) Then
                numberOfDependents = 1
                stringDependents = "Spouse"
            End If

            ' Save Information to Pass onto Results Page
            Dim taxInformation As New clsTaxReturn(CDec(txtSalaries.Text), CDec(txtTaxableInterest.Text), CDec(txtUnemployment.Text), CDec(txtFederalIncome.Text), CDec(txtEIC.Text), CDec(txtNonTaxable.Text), numberOfPeople, numberOfDependents, Server.MapPath("."))

            ' Session Variables
            Session.Add("taxInformation", taxInformation)
            Session.Add("stringNumberOfPeople", stringNumberOfPeople)
            Session.Add("numberOfPeople", numberOfPeople)
            Session.Add("stringNumberOfDependents", numberOfDependents)
            Session.Add("fullName", txtFullName.Text)

            ' Redirect to results page
            Response.Redirect("Result.aspx")

        Catch ex As Exception
            lblMessage.Text = ex.Message
        End Try
    End Sub

    ' Clear all the inofrmation and uncheck the boxes
    Protected Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtSalaries.Text = ""
        txtTaxableInterest.Text = ""
        txtUnemployment.Text = ""
        ckbYou.Checked = False
        ckbSpouse.Checked = False
        txtFederalIncome.Text = ""
        txtEIC.Text = ""
        txtNonTaxable.Text = ""
    End Sub
End Class